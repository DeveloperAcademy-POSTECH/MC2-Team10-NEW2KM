//
//  TargetItem+CoreDataClass.swift
//  Moasa
//
//  Created by Junyeong Park on 2022/06/10.
//
//

import CoreData
import Foundation


public class TargetItem: NSManagedObject {

}
