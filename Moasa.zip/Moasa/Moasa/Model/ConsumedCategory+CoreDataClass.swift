//
//  ConsumedCategory+CoreDataClass.swift
//  Moasa
//
//  Created by Junyeong Park on 2022/06/10.
//
//

import Foundation
import CoreData


public class ConsumedCategory: NSManagedObject {

}
